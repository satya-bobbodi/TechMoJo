package com.TechMoJo.TweetsExample;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Component;

@Component
public class MainTweetService {

	public void test() {
		System.out.println("Iam in service");
	}

	public HashMap<String, Integer> getTrendingTweets(List<String> tweetsList) {
		String spt [] = null;
		
			HashMap<String,Integer> cMap = countHastTag(tweetsList);
			cMap.entrySet().stream()
            .sorted(Map.Entry.comparingByValue())
            .forEachOrdered(x -> cMap.put(x.getKey(), x.getValue()));
		
		return cMap;
	}

	private HashMap<String, Integer> countHastTag(List<String> tweetsList) {
		// TODO Auto-generated method stub
		HashMap<String,Integer> dataStr = new HashMap<String, Integer>();
		
		for (String element : tweetsList) 
	    {   
	        if(dataStr.get(element) == null)
	        {
	        	dataStr.put(element, 1);
	        }
	        else
	        {
	        	dataStr.put(element, dataStr.get(element)+1);
	        }
	    }
		return dataStr;
	}
	
}
