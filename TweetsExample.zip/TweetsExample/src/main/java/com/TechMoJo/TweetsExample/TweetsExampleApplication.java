package com.TechMoJo.TweetsExample;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Scanner;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;

@SpringBootApplication
public class TweetsExampleApplication {

	@Autowired
	MainTweetService mainTweetService;
	static List<String> tweetsList = new ArrayList<String>();
	public static void main(String[] args) {
		//SpringApplication.run(TweetsExampleApplication.class, args);	
		ApplicationContext ctx = SpringApplication.run(TweetsExampleApplication.class, args);
		     
        MainTweetService ms = ctx.getBean(MainTweetService.class);
        System.out.println("Please tweet the Hastag");
        @SuppressWarnings("resource")
		Scanner scanner =  new Scanner(System.in);
		String value  = scanner.nextLine();
		if(value.contains("#")) {
			
			String spt [] = null;
			spt = value.split("#");
			// ("Best Company #TechMojo") , (My name is #satya)
				tweetsList.add(spt[1]);
				tweetsList.add("TechMojo");//ex : splited from above string (TechMojo)
				tweetsList.add("satya");
				tweetsList.add("TechMojo");
		}
        HashMap<String,Integer> tweets = ms.getTrendingTweets(tweetsList);
       // ObjectMapper objectMapper = new ObjectMapper();

        //try {
          //  String json = objectMapper.writeValueAsString(tweets);
           // System.out.println(json);
        //} catch (JsonProcessingException e) {
          //  e.printStackTrace();
       // }
        System.out.println(tweets);
	}

}
